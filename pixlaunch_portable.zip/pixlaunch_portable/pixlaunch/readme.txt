pixlaunch is an open source launcher for .html files.

Code available here.
https://github.com/pixleb/pixlaunch

